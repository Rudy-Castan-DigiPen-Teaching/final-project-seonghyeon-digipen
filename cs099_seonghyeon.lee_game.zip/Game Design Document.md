I will make a game to hit the target.

you can adjust angle of cannon and you can shoot bullet. 

 you have to hit target to clear. 
 
I will use googly eyes to make a target and I will make cannon to shoot bullets.

I will make four button. 

First play button. If you click this button, you can choose 3 part .

Second options button. If you click this button. you can choose color of cannon.

Third Credits button. If you click this button. you can know who make this game and who help to make a game.

Four How to play button. If you click this button you can know how to play the game.
