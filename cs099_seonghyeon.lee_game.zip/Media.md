BG.png and 2.png : https://www.gameart2d.com/free-platformer-game-tileset.html
License(s): Creative Common Zero (CC0) a.k.a Public Domain license.

cannon ball.png : https://opengameart.org/content/cannonball
Author: DontMind8
License(s): CC-BY 4.0 , CC0

shield.png : https://opengameart.org/content/shield-sprite
Author: zeroisnotnull
License(s): CC0

wall.png : https://opengameart.org/content/handpainted-stone-wall-textures
Author: PamNawi
License(s): CC-BY 4.0 , CC0

sunset.png : https://opengameart.org/content/oil-painting-landscapes
Author: JAP
License(s): CC0

BG2.png : https://opengameart.org/content/backdrop-mountains
Author: bloodywing
License(s): CC-BY 3.0

Windows.png : https://www.gameart2d.com/free-fantasy-game-gui.html
License(s): Creative Common Zero (CC0) a.k.a Public Domain license.

game2.png : I made it myself.

MainMenu.mp3 : https://opengameart.org/content/town-theme-rpg
Author: cynicmusic
License(s): CC0

bang_01.ogg : https://opengameart.org/content/25-cc0-bang-firework-sfx
Author: rubberduck
License(s): CC0

tropcool.ogg : https://opengameart.org/content/human-voice-cool
Author: farfadet46
License(s): CC0
