// SeongHyeon Lee
// CS099 Final Project - Make a Game
// CS099
// Spring 2020.7.08
const MAIN_MENU = 1;
const CREDITS_SCREEN = 2;
const OPTIONS_SCREEN = 3;
const PART_SCREEN = 4;
const PART1_SCREEN = 5;
const PART2_SCREEN = 6;
const PART3_SCREEN = 7;
const Clear_SCREEN = 8;
const HowToPlaySCREEN = 9;
const Ending_SCREEN = 10;
