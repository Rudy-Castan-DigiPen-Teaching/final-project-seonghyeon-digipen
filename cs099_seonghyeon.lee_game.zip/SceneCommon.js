
// SeongHyeon Lee
// CS099 Final Project - Make a Game
// CS099
// Spring 2020.7.08
function DrawTitle(label){
    push();
    textAlign(CENTER);
    textSize(55);
    fill(0);
    noStroke();
    text(label, width/2, height/2 - 200);
    pop();
}