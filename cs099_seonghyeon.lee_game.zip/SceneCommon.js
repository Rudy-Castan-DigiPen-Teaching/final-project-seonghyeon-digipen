

function DrawTitle(label){
    push();
    textAlign(CENTER);
    textSize(55);
    fill(0);
    noStroke();
    text(label, width/2, height/2 - 200);
    pop();
}