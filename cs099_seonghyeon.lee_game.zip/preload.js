// SeongHyeon Lee
// CS099 Final Project - Make a Game
// CS099
// Spring 2020.7.08
function preload(){
 BG = loadImage('Image/BG.png')
Tile = loadImage('Image/2.png')
  // Cannon = loadImage('Image/cannon1.png')
  Cannon_Ball = loadImage('Image/cannon ball.png')
  Cannon_Ball2 = loadImage('Image/shield.png')
  Wall = loadImage('Image/wall.png')
  BG1 = loadImage('Image/sunset.png')
  BG2 = loadImage('Image/BG2.png')
   BG3 = loadImage('Image/Windows.png')
  Htp = loadImage('Image/game2.png')
  
  Mm = loadSound('Music/Main Menu.mp3')
  bang = loadSound('Music/bang_01.ogg')
  wow = loadSound('Music/tropcool.ogg')

}